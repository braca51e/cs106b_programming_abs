#ifndef PlayingFairTests_Included
#define PlayingFairTests_Included

#include "TestDriver.h"

/* This logic is necessary to get the testing harness to properly pick up all the tests
 * from your file.
 */
#ifdef GROUP
#undef GROUP
#endif

#define GROUP {2, "Playing Fair"}

#endif

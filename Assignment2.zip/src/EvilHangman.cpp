/* File: EvilHangman.cpp
 *
 * TODO: Delete this comment and replace it with something more insightful about how your
 * program works.
 */

#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
#include "Testing/HangmanTests.h"
using namespace std;

/* This unusual multimain macro is part of the Stanford C++ Libraries. It's what enables us to
 * have multiple independent programs that are all part of the same project. Normally, you
 * would just call this main() without any fancy adornment, but since we're building a single
 * project that also includes Crystals and our testing driver, we need to do this to ensure
 * that everything builds properly.
 *
 * TODO: Delete this comment after you've read it.
 */
int multimain(EvilHangman) {
    /* TODO: Delete this comment and fill in this main function. */

    return 0;
}

/* * * * * * Add Testing Code Here * * * * * */

/* TODO: Write unit tests for three of your functions. Don't put this off until the end; that's an
 * easy way to spend a lot of time fighting bugs in a complex system. Instead, test as you go.
 */

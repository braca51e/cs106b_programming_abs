#ifndef GUIMain_Included
#define GUIMain_Included

/* Runs the main loop for the interactive graphical program. */
void guiMain();

#endif
